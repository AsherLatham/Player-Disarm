[title]
PlayerDisarm
[desc]
Disarm the player's weapon and surrender with hands up.
[Use]
Place folder 'playerdisarm' in to FXServer resource folder.
Append server config (def. server.cfg) with 'Start playerdisarm'.
Script is non-dependant on boot order.
Hold X to disarm.
[Author]
Asher Latham ~ https://git.io/fptUE
[Version]
1.0